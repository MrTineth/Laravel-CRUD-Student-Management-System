<div class="footer">
    <p>Copyright © Dream Design Solutions 2023 </p>
</div><?php /**PATH G:\Laravel\CRUD-Operation\resources\views/components/footer.blade.php ENDPATH**/ ?>