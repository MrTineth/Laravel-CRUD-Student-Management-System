<div class="footer">
    <p>Copyright © Dream Design Solutions 2023 </p>
</div>